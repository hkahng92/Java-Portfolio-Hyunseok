package com.company.retailapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetailApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetailApiApplication.class, args);
	}

}
